  Caltech4 Dataset Information:

                Train       Test
-------------------------------------
airplanes       500         50
cars            465         50
faces           400         50
motorbikes      500         50
-------------------------------------
T.t.l           1865        200



The 'Template_Result.html' should show images normally when Caltech4 folder presents.

The Caltech4 dataset folder it organised as follows,
------------------------
Caltech4
    Annotation
    FeatureData
    ImageData
    ImageSets
------------------------

ImageData folder contains all images used in this assignment.
We have generate some Annotation and ImageSets for you.
For easy debuging, we recomend you to generate and store your
train/test example list into files under Annotation folder,
instead of doing it dynamically in your code.
Also, put you extracted feature under FeatureData folder is a good habit.

================================================================
You are expected to submit at least 3 html files (by filling in Template_Result.html with your ranking list),
 demonstrating your result on the required features: RGBSIFT, rgbSIFT and opponentSIFT.
================================================================

Note: when you submit your assignment, don't put Caltech4 data in your folder.

